MushHub press kit · https://mushhub.stream/prensa.html · https://mushhub.stream/press.html

Contact / Contacto: contacto@mushhub.stream

COLORS / COLORES
  #070816 background · #12152B surface · #F500D7 magenta · #8B32FF violet · #00E5F2 cyan · #F7F4FF text

FONTS / TIPOGRAFIAS
  Bricolage Grotesque (headings) · Manrope (body)

CLIPS: real SMITE 2 match from the MushInGames account. Credit MushHub / mushhub.stream.

MushHub is independent and not affiliated with Twitch, Kick, YouTube, Google, TikTok or OBS.

--- EN ---
MushHub is a streaming assistant for Windows that controls OBS with your voice, merges the chat from Twitch, Kick, YouTube and TikTok and saves your best plays.

MushHub is a free Windows app built for streamers. It connects OBS with Twitch, Kick, YouTube and TikTok, merges every chat into one column, sets and applies your live titles with your voice and, with AI that runs on your PC, finds and crops your best moments in vertical.

MushHub is a Windows app that does the boring part of streaming. You download and install it: no account is needed to use it. It controls OBS with your voice (scenes, mute, recording and Replay Buffer), brings together the chat from Twitch, Kick, YouTube and TikTok with their emotes and lets you reply to every platform at once. It prepares and applies your live titles and categories, always with a preview and your confirmation. MushAI, an AI that runs on your PC, listens to your recording, checks how chat reacted and suggests the best moments, which you can export in vertical with subtitles for TikTok, Reels and Shorts. Your recordings, clips and settings stay on your computer, and accounts connect through each platform's official authorization: MushHub never sees your passwords. It is independent and not affiliated with Twitch, Kick, YouTube, Google, TikTok or OBS.

--- ES ---
MushHub es un asistente de streaming para Windows que controla OBS con tu voz, junta el chat de Twitch, Kick, YouTube y TikTok y guarda tus mejores jugadas.

MushHub es una app gratuita para Windows hecha para streamers. Conecta OBS con Twitch, Kick, YouTube y TikTok, junta todos los chats en una sola columna, prepara y aplica los títulos de tu directo con tu voz y, con una IA que corre en tu PC, encuentra y recorta tus mejores momentos en vertical.

MushHub es una app para Windows que hace el trabajo aburrido del stream. Se descarga y se instala: no necesitas crear una cuenta para usarla. Controla OBS con tu voz (escenas, mute, grabación y Replay Buffer), junta el chat de Twitch, Kick, YouTube y TikTok con sus emotes y deja responder a todas las plataformas a la vez. Prepara y aplica los títulos y categorías de tu directo, siempre con vista previa y tu confirmación. MushAI, una IA que corre en tu PC, escucha tu grabación, mira cómo reaccionó el chat y propone los mejores momentos, que puedes exportar en vertical con subtítulos para TikTok, Reels y Shorts. Tus grabaciones, clips y ajustes se quedan en tu computadora, y las cuentas se conectan con la autorización oficial de cada plataforma: MushHub nunca ve tus contraseñas. Es independiente y no está afiliado a Twitch, Kick, YouTube, Google, TikTok ni OBS.
